/*! DataTables styling wrapper for Responsive
 * © SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net-dt';
import 'datatables.net-responsive';




export default DataTable;
