﻿using System;
using System.Collections.Generic;

namespace Actividad2_OGS_MODULO2.Models
{
    public partial class ProductsAboveAveragePrice
    {
        public string ProductName { get; set; }
        public decimal? UnitPrice { get; set; }
    }
}
