﻿using _20221124_APINeptuno.Dal;
using _20221125_ClienteNeptuno.Services.Interfaces;
using System.Threading.Tasks;

namespace _20221125_ClienteNeptuno.Services
{
    public class UsersService : IUsersService
    {
        public Task<User> DoLogin(string login, string password)
        {
            return null;
        }
    }
}
