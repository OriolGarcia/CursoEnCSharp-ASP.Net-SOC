﻿using _20221125_ClienteNeptuno.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace _20221125_ClienteNeptuno.Controllers
{
    public class UsersController : Controller
    {
        private IUsersService service;
        public UsersController(IUsersService _service)
        {
            service = _service;
        }

        [HttpGet]
        public IActionResult Login()
        {
            //Presenta el formulario de login
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> DoLogin(string login, string password)
        {
            //validación de si el login es correcto
            var user = await service.DoLogin(login,password);
            return View();
        }

    }
}
